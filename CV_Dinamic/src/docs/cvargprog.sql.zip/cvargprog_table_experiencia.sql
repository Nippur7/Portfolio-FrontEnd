
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `experiencia`
--
-- Creación: 12-01-2023 a las 23:40:45
-- Última actualización: 13-01-2023 a las 20:00:30
--

DROP TABLE IF EXISTS `experiencia`;
CREATE TABLE `experiencia` (
  `idexperiencia` int(11) NOT NULL,
  `imagen` mediumblob DEFAULT NULL,
  `lugar` varchar(30) DEFAULT NULL,
  `inicio` date DEFAULT NULL,
  `fin` date DEFAULT NULL,
  `iddetalles` int(11) NOT NULL,
  `tipo` int(11) DEFAULT NULL,
  `obs` varchar(30) DEFAULT NULL,
  `iduser` int(11) NOT NULL,
  `modificado` date DEFAULT NULL,
  `detalles` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Truncar tablas antes de insertar `experiencia`
--

TRUNCATE TABLE `experiencia`;
--
-- Volcado de datos para la tabla `experiencia`
--

INSERT INTO `experiencia` (`idexperiencia`, `imagen`, `lugar`, `inicio`, `fin`, `iddetalles`, `tipo`, `obs`, `iduser`, `modificado`, `detalles`) VALUES
(4, '', 'DEMISA CONSTRUCCIONES S.A.', '2007-10-31', '2021-08-29', 1, 2, '0', 10, '2023-01-07', 0),
(6, '', 'Henry', '2022-01-01', '2023-01-01', 2, 1, '0', 10, '2023-01-12', 0);

--
-- Disparadores `experiencia`
--
DROP TRIGGER IF EXISTS `experiencia_BEFORE_INSERT`;
DELIMITER $$
CREATE TRIGGER `experiencia_BEFORE_INSERT` BEFORE INSERT ON `experiencia` FOR EACH ROW BEGIN
	set NEW.modificado = CURRENT_TIMESTAMP;
END
$$
DELIMITER ;
