
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `experiencia`
--

DROP TABLE IF EXISTS `experiencia`;
CREATE TABLE `experiencia` (
  `idexperiencia` int(11) NOT NULL,
  `imagen` varchar(64) DEFAULT NULL,
  `lugar` varchar(30) DEFAULT NULL,
  `inicio` date DEFAULT NULL,
  `fin` date DEFAULT NULL,
  `iddetalles` int(11) NOT NULL,
  `tipo` int(11) NOT NULL,
  `obs` varchar(30) DEFAULT NULL,
  `iduser` int(11) NOT NULL,
  `modificado` date DEFAULT NULL,
  `detalles` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELACIONES PARA LA TABLA `experiencia`:
--   `tipo`
--       `tipo` -> `idtipo`
--   `iddetalles`
--       `detalle` -> `iddetalles`
--   `iduser`
--       `usuario` -> `idusuario`
--

--
-- Volcado de datos para la tabla `experiencia`
--

INSERT INTO `experiencia` (`idexperiencia`, `imagen`, `lugar`, `inicio`, `fin`, `iddetalles`, `tipo`, `obs`, `iduser`, `modificado`, `detalles`) VALUES
(6, '', 'Henry', '2022-01-01', '2023-01-01', 2, 4, '0', 10, '2023-01-12', 0),
(14, NULL, 'Argentina Programa', '2021-12-31', '2022-12-31', 1, 4, 'Casi terminamos', 10, '2023-01-13', NULL),
(15, NULL, 'Argentina Programa', '2021-12-30', '2022-12-30', 2, 4, 'Se fué con Lisandro', 57, '2023-01-13', NULL);

--
-- Disparadores `experiencia`
--
DROP TRIGGER IF EXISTS `experiencia_BEFORE_INSERT`;
DELIMITER $$
CREATE TRIGGER `experiencia_BEFORE_INSERT` BEFORE INSERT ON `experiencia` FOR EACH ROW BEGIN
	set NEW.modificado = CURRENT_TIMESTAMP;
END
$$
DELIMITER ;
