
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle`
--
-- Creación: 12-01-2023 a las 23:52:27
--

DROP TABLE IF EXISTS `detalle`;
CREATE TABLE `detalle` (
  `iddetalles` int(11) NOT NULL,
  `puesto` varchar(30) DEFAULT NULL,
  `descripción` varchar(80) DEFAULT NULL,
  `obs` varchar(20) DEFAULT NULL,
  `iduser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Truncar tablas antes de insertar `detalle`
--

TRUNCATE TABLE `detalle`;
--
-- Volcado de datos para la tabla `detalle`
--

INSERT INTO `detalle` (`iddetalles`, `puesto`, `descripción`, `obs`, `iduser`) VALUES
(1, 'IT', 'DATA ENTRY', '0', 55),
(2, 'DATA SCIENTIST', 'BOOTCAMP DATA SCIENTIST', '6 MESES ', 10),
(3, 'IT', 'DATA ENTRY', '0', 10);
