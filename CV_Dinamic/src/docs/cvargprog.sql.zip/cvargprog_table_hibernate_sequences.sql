
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hibernate_sequences`
--
-- Creación: 13-01-2023 a las 04:32:48
--

DROP TABLE IF EXISTS `hibernate_sequences`;
CREATE TABLE `hibernate_sequences` (
  `sequence_name` varchar(255) NOT NULL,
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Truncar tablas antes de insertar `hibernate_sequences`
--

TRUNCATE TABLE `hibernate_sequences`;
--
-- Volcado de datos para la tabla `hibernate_sequences`
--

INSERT INTO `hibernate_sequences` (`sequence_name`, `next_val`) VALUES
('default', 100);
