
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_seq`
--

DROP TABLE IF EXISTS `tipo_seq`;
CREATE TABLE `tipo_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELACIONES PARA LA TABLA `tipo_seq`:
--

--
-- Volcado de datos para la tabla `tipo_seq`
--

INSERT INTO `tipo_seq` (`next_val`) VALUES
(101);
