
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_seq`
--
-- Creación: 13-01-2023 a las 04:34:38
--

DROP TABLE IF EXISTS `tipo_seq`;
CREATE TABLE `tipo_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Truncar tablas antes de insertar `tipo_seq`
--

TRUNCATE TABLE `tipo_seq`;
--
-- Volcado de datos para la tabla `tipo_seq`
--

INSERT INTO `tipo_seq` (`next_val`) VALUES
(101);
