
--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `contacto`
--
ALTER TABLE `contacto`
  ADD PRIMARY KEY (`idactividad`);

--
-- Indices de la tabla `detalle`
--
ALTER TABLE `detalle`
  ADD PRIMARY KEY (`iddetalles`);

--
-- Indices de la tabla `experiencia`
--
ALTER TABLE `experiencia`
  ADD PRIMARY KEY (`idexperiencia`),
  ADD KEY `delete_exp` (`iduser`),
  ADD KEY `delete_det` (`iddetalles`);

--
-- Indices de la tabla `hibernate_sequences`
--
ALTER TABLE `hibernate_sequences`
  ADD PRIMARY KEY (`sequence_name`);

--
-- Indices de la tabla `proyecto`
--
ALTER TABLE `proyecto`
  ADD PRIMARY KEY (`idproyecto`);

--
-- Indices de la tabla `skill`
--
ALTER TABLE `skill`
  ADD PRIMARY KEY (`idskill`),
  ADD KEY `delete_skill` (`iduser`);

--
-- Indices de la tabla `tipo`
--
ALTER TABLE `tipo`
  ADD PRIMARY KEY (`idtipo`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`idusuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `contacto`
--
ALTER TABLE `contacto`
  MODIFY `idactividad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `detalle`
--
ALTER TABLE `detalle`
  MODIFY `iddetalles` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `experiencia`
--
ALTER TABLE `experiencia`
  MODIFY `idexperiencia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `proyecto`
--
ALTER TABLE `proyecto`
  MODIFY `idproyecto` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `skill`
--
ALTER TABLE `skill`
  MODIFY `idskill` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `tipo`
--
ALTER TABLE `tipo`
  MODIFY `idtipo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `experiencia`
--
ALTER TABLE `experiencia`
  ADD CONSTRAINT `delete_det` FOREIGN KEY (`iddetalles`) REFERENCES `detalle` (`iddetalles`),
  ADD CONSTRAINT `delete_exp` FOREIGN KEY (`iduser`) REFERENCES `usuario` (`idusuario`);

--
-- Filtros para la tabla `skill`
--
ALTER TABLE `skill`
  ADD CONSTRAINT `delete_skill` FOREIGN KEY (`iduser`) REFERENCES `usuario` (`idusuario`);


--
-- Metadatos
--
USE `phpmyadmin`;

--
-- Metadatos para la tabla contacto
--

--
-- Metadatos para la tabla detalle
--

--
-- Metadatos para la tabla experiencia
--

--
-- Metadatos para la tabla hibernate_sequences
--

--
-- Metadatos para la tabla proyecto
--

--
-- Metadatos para la tabla skill
--

--
-- Metadatos para la tabla tipo
--

--
-- Metadatos para la tabla tipo_seq
--

--
-- Metadatos para la tabla usuario
--

--
-- Metadatos para la tabla usuario_seq
--

--
-- Metadatos para la base de datos cvargprog
--

--
-- Volcado de datos para la tabla `pma__relation`
--

INSERT INTO `pma__relation` (`master_db`, `master_table`, `master_field`, `foreign_db`, `foreign_table`, `foreign_field`) VALUES
('cvargprog', 'contacto', 'iduser', 'cvargprog', 'usuario', 'idusuario'),
('cvargprog', 'experiencia', 'tipo', 'cvargprog', 'tipo', 'idtipo'),
('cvargprog', 'proyecto', 'iduser', 'cvargprog', 'usuario', 'idusuario');

--
-- Volcado de datos para la tabla `pma__pdf_pages`
--

INSERT INTO `pma__pdf_pages` (`db_name`, `page_descr`) VALUES
('cvargprog', 'der_arg_prog');

SET @LAST_PAGE = LAST_INSERT_ID();

--
-- Volcado de datos para la tabla `pma__table_coords`
--

INSERT INTO `pma__table_coords` (`db_name`, `table_name`, `pdf_page_number`, `x`, `y`) VALUES
('cvargprog', 'contacto', @LAST_PAGE, 60, 500),
('cvargprog', 'detalle', @LAST_PAGE, 746, 251),
('cvargprog', 'experiencia', @LAST_PAGE, 469, 217),
('cvargprog', 'hibernate_sequences', @LAST_PAGE, 44, 17),
('cvargprog', 'proyecto', @LAST_PAGE, 468, 589),
('cvargprog', 'skill', @LAST_PAGE, 728, 23),
('cvargprog', 'tipo', @LAST_PAGE, 784, 508),
('cvargprog', 'tipo_seq', @LAST_PAGE, 513, 18),
('cvargprog', 'usuario', @LAST_PAGE, 59, 171),
('cvargprog', 'usuario_seq', @LAST_PAGE, 290, 20);
