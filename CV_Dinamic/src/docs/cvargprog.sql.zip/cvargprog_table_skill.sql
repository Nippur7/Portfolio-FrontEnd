
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `skill`
--
-- Creación: 13-01-2023 a las 05:00:06
--

DROP TABLE IF EXISTS `skill`;
CREATE TABLE `skill` (
  `idskill` int(11) NOT NULL,
  `detalle` varchar(30) DEFAULT NULL,
  `porcentaje` float DEFAULT NULL,
  `experiencia` int(11) DEFAULT NULL,
  `modificado` date DEFAULT NULL,
  `iduser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Truncar tablas antes de insertar `skill`
--

TRUNCATE TABLE `skill`;
--
-- Volcado de datos para la tabla `skill`
--

INSERT INTO `skill` (`idskill`, `detalle`, `porcentaje`, `experiencia`, `modificado`, `iduser`) VALUES
(1, 'python', 82, 2, '2023-01-08', 10),
(3, 'Power Bi', 81.8, 2, '2023-01-13', 10);

--
-- Disparadores `skill`
--
DROP TRIGGER IF EXISTS `skill_BEFORE_INSERT`;
DELIMITER $$
CREATE TRIGGER `skill_BEFORE_INSERT` BEFORE INSERT ON `skill` FOR EACH ROW BEGIN
	set NEW.modificado = CURRENT_TIMESTAMP;
END
$$
DELIMITER ;
