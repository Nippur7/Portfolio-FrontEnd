
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `skill`
--

DROP TABLE IF EXISTS `skill`;
CREATE TABLE `skill` (
  `idskill` int(11) NOT NULL,
  `detalle` varchar(30) DEFAULT NULL,
  `porcentaje` float DEFAULT NULL,
  `experiencia` int(11) DEFAULT NULL,
  `modificado` date DEFAULT NULL,
  `iduser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELACIONES PARA LA TABLA `skill`:
--   `iduser`
--       `usuario` -> `idusuario`
--

--
-- Volcado de datos para la tabla `skill`
--

INSERT INTO `skill` (`idskill`, `detalle`, `porcentaje`, `experiencia`, `modificado`, `iduser`) VALUES
(1, 'PowerBi', 90, 2, '2023-01-08', 10),
(4, 'Python', 90, 2, '2023-01-13', 10),
(6, 'ETL', 85.2, 2, '2023-01-13', 10);

--
-- Disparadores `skill`
--
DROP TRIGGER IF EXISTS `skill_BEFORE_INSERT`;
DELIMITER $$
CREATE TRIGGER `skill_BEFORE_INSERT` BEFORE INSERT ON `skill` FOR EACH ROW BEGIN
	set NEW.modificado = CURRENT_TIMESTAMP;
END
$$
DELIMITER ;
