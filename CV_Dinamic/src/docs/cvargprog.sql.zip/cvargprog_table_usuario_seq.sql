
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_seq`
--

DROP TABLE IF EXISTS `usuario_seq`;
CREATE TABLE `usuario_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELACIONES PARA LA TABLA `usuario_seq`:
--

--
-- Volcado de datos para la tabla `usuario_seq`
--

INSERT INTO `usuario_seq` (`next_val`) VALUES
(151);
