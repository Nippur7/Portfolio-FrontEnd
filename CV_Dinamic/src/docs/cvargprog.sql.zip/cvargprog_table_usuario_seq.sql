
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_seq`
--
-- Creación: 12-01-2023 a las 04:14:22
--

DROP TABLE IF EXISTS `usuario_seq`;
CREATE TABLE `usuario_seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Truncar tablas antes de insertar `usuario_seq`
--

TRUNCATE TABLE `usuario_seq`;
--
-- Volcado de datos para la tabla `usuario_seq`
--

INSERT INTO `usuario_seq` (`next_val`) VALUES
(151);
