
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `idusuario` int(11) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(50) NOT NULL,
  `ingreso` date NOT NULL,
  `aboutme` varchar(45) DEFAULT NULL,
  `picture` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELACIONES PARA LA TABLA `usuario`:
--

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`idusuario`, `apellido`, `nombre`, `email`, `password`, `ingreso`, `aboutme`, `picture`) VALUES
(10, 'MATICH CUEZZO', 'CARLOS ANTONIO', 'NIPPUR.ARGENTO@GMAIL.COM', '123456', '2023-01-08', NULL, NULL),
(57, 'MATICH MEDINA', 'JESÚS', 'PRUEBA@GMAIL.COM', '123456', '2023-01-13', 'chichito', NULL);

--
-- Disparadores `usuario`
--
DROP TRIGGER IF EXISTS `usuario_BEFORE_UPDATE`;
DELIMITER $$
CREATE TRIGGER `usuario_BEFORE_UPDATE` BEFORE INSERT ON `usuario` FOR EACH ROW BEGIN	    
		set NEW.ingreso = CURRENT_TIMESTAMP;
END
$$
DELIMITER ;
