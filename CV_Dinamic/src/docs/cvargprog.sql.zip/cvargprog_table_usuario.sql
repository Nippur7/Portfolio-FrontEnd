
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--
-- Creación: 11-01-2023 a las 22:28:34
-- Última actualización: 13-01-2023 a las 20:00:37
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `idusuario` int(11) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(50) NOT NULL,
  `ingreso` date NOT NULL,
  `aboutme` varchar(45) DEFAULT NULL,
  `picture` mediumblob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Truncar tablas antes de insertar `usuario`
--

TRUNCATE TABLE `usuario`;
--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`idusuario`, `apellido`, `nombre`, `email`, `password`, `ingreso`, `aboutme`, `picture`) VALUES
(10, 'MATICH CUEZZO', 'CARLOS ANTONIO', 'NIPPUR.ARGENTO@GMAIL.COM', '123456', '2023-01-08', NULL, NULL);

--
-- Disparadores `usuario`
--
DROP TRIGGER IF EXISTS `usuario_BEFORE_UPDATE`;
DELIMITER $$
CREATE TRIGGER `usuario_BEFORE_UPDATE` BEFORE INSERT ON `usuario` FOR EACH ROW BEGIN	    
		set NEW.ingreso = CURRENT_TIMESTAMP;
END
$$
DELIMITER ;
