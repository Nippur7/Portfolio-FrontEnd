
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contacto`
--

DROP TABLE IF EXISTS `contacto`;
CREATE TABLE `contacto` (
  `idactividad` int(11) NOT NULL,
  `click` varchar(30) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `iduser` int(11) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `celular` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELACIONES PARA LA TABLA `contacto`:
--   `iduser`
--       `usuario` -> `idusuario`
--

--
-- Volcado de datos para la tabla `contacto`
--

INSERT INTO `contacto` (`idactividad`, `click`, `cantidad`, `fecha`, `iduser`, `email`, `celular`) VALUES
(17, 'linkedin', 1, '2023-11-30', 10, 'prueba1@hotmail.com', '+543885914783'),
(18, 'Whatsapp', 2, '2023-11-29', 10, 'Chichito@hotmail.com', '+543885914783'),
(19, 'Facebook', 4, NULL, 10, 'pruebita2@hotmail.com', '+543885914783');
