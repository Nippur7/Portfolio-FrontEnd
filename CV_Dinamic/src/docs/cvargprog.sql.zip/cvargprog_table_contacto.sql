
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contacto`
--
-- Creación: 13-01-2023 a las 13:57:55
-- Última actualización: 13-01-2023 a las 20:05:19
--

DROP TABLE IF EXISTS `contacto`;
CREATE TABLE `contacto` (
  `idactividad` int(11) NOT NULL,
  `click` varchar(30) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `iduser` int(11) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `celular` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Truncar tablas antes de insertar `contacto`
--

TRUNCATE TABLE `contacto`;
--
-- Volcado de datos para la tabla `contacto`
--

INSERT INTO `contacto` (`idactividad`, `click`, `cantidad`, `fecha`, `iduser`, `email`, `celular`) VALUES
(17, 'linkedin', 1, '2023-11-30', 10, 'prueba1@hotmail.com', '+543885914783');
