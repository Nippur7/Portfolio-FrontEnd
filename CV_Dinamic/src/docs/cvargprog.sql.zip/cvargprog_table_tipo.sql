
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo`
--
-- Creación: 13-01-2023 a las 04:36:15
--

DROP TABLE IF EXISTS `tipo`;
CREATE TABLE `tipo` (
  `idtipo` int(11) NOT NULL,
  `descripcion` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Truncar tablas antes de insertar `tipo`
--

TRUNCATE TABLE `tipo`;
--
-- Volcado de datos para la tabla `tipo`
--

INSERT INTO `tipo` (`idtipo`, `descripcion`) VALUES
(1, 'Trabajo'),
(2, 'estudio'),
(3, 'Prueba');
